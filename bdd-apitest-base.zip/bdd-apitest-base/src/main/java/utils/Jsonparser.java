package utils;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;

import io.restassured.response.Response;

public class Jsonparser {

	public static JsonObject gettestcasedata(String inputfile) {

		JsonObject jo = null;
		try {

			// create a reader
			Reader reader = Files.newBufferedReader(Paths.get(inputfile));
			JsonElement tree = JsonParser.parseReader(reader);

			if (tree.isJsonObject()) {
				jo = tree.getAsJsonObject();

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return (jo);
	}

	public static HashMap<String, String> getheadermap(JsonElement je) {
		HashMap<String, String> hm = new HashMap<String, String>();
		JSONParser parser = new JSONParser();
		System.out.println(" Inside header make function ");
		try {

			Object obj = parser.parse(je.toString());

			JSONArray jsonArray = (JSONArray) obj;

			Iterator<JSONObject> iterator = jsonArray.iterator();
			while (iterator.hasNext()) {
				JSONObject jsonObj = iterator.next();
				String name = (String) jsonObj.get("key");
				String content = (String) jsonObj.get("value");
				hm.put(name.replaceAll("\"", ""), content.replaceAll("\"", ""));
			}
		} catch (ParseException p) {
		}
		System.out.println("PRINT HM" + hm);
		return hm;
	}

	public static HashMap<String, String[]> getassertionmap(JsonElement je) {
		HashMap<String, String[]> hm = new HashMap<String, String[]>();
		JSONParser parser = new JSONParser();
		System.out.println(" Inside header make function ");
		try {

			Object obj = parser.parse(je.toString());

			JSONArray jsonArray = (JSONArray) obj;

			Iterator<JSONObject> iterator = jsonArray.iterator();
			while (iterator.hasNext()) {
				JSONObject jsonObj = iterator.next();
				String name = (String) jsonObj.get("key");
				String content = (String) jsonObj.get("value");
				String[] contentlist = content.split(",");
				hm.put(name.replaceAll("\"", ""), contentlist);
			}
		} catch (ParseException p) {
		}

		return hm;
	}

	public static String getjsonpathvalue(Response response, String jpath) {
		String expectedJpathvalue = null;
		try {
			expectedJpathvalue = JsonPath.parse(response.asInputStream()).read(jpath, String.class);
			return expectedJpathvalue;
		} catch (NullPointerException e) {
			System.out.println("Jpath exception :" + e.toString());
			expectedJpathvalue = "No Value for given Json path";
			return expectedJpathvalue;
		} catch (com.jayway.jsonpath.PathNotFoundException p) {
			System.out.println("Jpath exception :" + p.toString());
			expectedJpathvalue = "No Value for given Json path";
			return expectedJpathvalue;
		}

	}

}
