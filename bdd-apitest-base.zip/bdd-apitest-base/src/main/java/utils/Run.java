package utils;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.*;
import static org.junit.Assert.assertEquals;
import static org.hamcrest.Matchers.equalTo;
import java.util.HashMap;
import java.util.Map;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import assertion.AssertJsonPath;
import assertion.HttpCdAssertion;
import io.restassured.response.Response;
import mockService.Setupmock;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
public class Run {

	public static void main(String[] args) {
		Setupmock mock = new Setupmock();
		WireMockServer wireMockServer = new WireMockServer(options().dynamicPort());
		String mockserviceurl=mock.setupStub("./resources_test/stub_files/schemar.json", 8092, "/fetchuser", wireMockServer);
		System.out.println("Mock service endpoint is : "+mockserviceurl);
	}

}
