package utils;

import java.util.Collection;
import java.util.List;

import cucumber.api.Result.Type;

public interface Scenario {
	Collection<String> getSourceTagNames();

	Type getStatus();

	boolean isFailed();

	void embed(byte[] var1, String var2);

	void write(String var1);

	String getname();

	String getID();

	String getUri();

	List<Integer> getlines();

}
