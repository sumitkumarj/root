package utils;

public class Logger {
	
	public static void writelog(String message, Object value)
	{
		System.out.println(message + value);
	}
	
	public static void writelog(String message)
	{
		System.out.println(message);
	}
	
	public static void writelog(Object message)
	{
		System.out.println(message);
	}
	
	public static void writelog(String message, String value)
	{
		System.out.println(message + value);
	}
	public static void writelog(String message, Object value1, String value2)
	{
		System.out.println(message + value1 + value2);
	}
	
	public static void writelog(String message, String value1, String value2, String value3, String value4)
	{
		System.out.println(message + value1 + value2 + value3 + value4);
	}

}
