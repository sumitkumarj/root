package assertion;

public class HttpCdAssertion {

	public static boolean asserthttpcd(String actualcd, String expectedcd) {
		System.out.println("*********************STARTING HTTP CODE ASSERTION**************************");

		if (actualcd.equalsIgnoreCase(expectedcd)) {
			System.out.println(" Http Status Code is TRUE.\n Expected Value is :" + expectedcd + "\n"
					+ " Actual value is: " + actualcd);
			System.out.println("*****************HTTP STATUS CODE ASSERTION COMPLETED**************************");
			return true;
		} else {
			System.out.println(" Http Status Code is FALSE.\n Expected Value is :" + expectedcd + "\n"
					+ " Actual value is: " + actualcd);
			System.out.println("*****************HTTP STATUS CODE ASSERTION COMPLETED**************************");
			return false;
		}
	}

}
