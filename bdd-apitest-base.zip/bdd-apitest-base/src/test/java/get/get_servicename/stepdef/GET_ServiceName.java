package get.get_servicename.stepdef;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import assertion.StringAssertion;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import mockService.Setupmock;
import utils.CustomLogFilter;
import utils.Jsonparser;
import utils.Logger;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
/*
This call is step defination for a service which uses HTTP GET method, to use rename class name as per your service name, this class and corresponding feature file have to be 
glued in junit Runner.java
*/
import static org.junit.Assert.assertTrue;

public class GET_ServiceName {

	String tcid = null;
	String desc = null;
	String uri = null;
	String resource = null;
	String parameters = null;
	String httpMethod = null;
	String inputToken = null;
	String inputrequest = null;
	HashMap<String, String> headers = null;
	HashMap<String, String[]> assertion = null;
	HashMap<String, String> database = null;
	Response response = null;
	String res = null;
	Scenario scenario;
	CustomLogFilter logFilter;
	RequestSpecification request;
	String mockserviceurl = null;

	// Cucumber hook for logging all request response in report.
	@Before
	public void before(Scenario scenario) {
		Logger.writelog("Scenario name is :" , scenario);
		this.scenario = scenario;
		logFilter = new CustomLogFilter();
		request = RestAssured.with();
	}

	@Before
	public void startmockserver() {
		Setupmock mock = new Setupmock();
		WireMockServer wireMockServer = new WireMockServer(options().dynamicPort());
		String mockurl = mock.setupStub(
				System.getProperty("user.dir") + "/src/test/resources/MockResponse/GetMockResponse.json", 8092,
				"/fetchuser", wireMockServer);
		mockserviceurl = "http://" + mockurl;
		Logger.writelog("Mock service endpoint is : " , mockserviceurl);
	}

	// This is a request builder section - all request parameters are constructed
	// from test case json file.
	@Test
	@Given("^I want to run test case for Get service from input data \"([^\"]*)\"$")
	public void request_builder(String testcasefilepath) {
		// Write code here that turns the phrase above into concrete actions
		Logger.writelog("Inside request builder function - GIVEN");
		String basepath = System.getProperty("user.dir");
		JsonObject jo = Jsonparser.gettestcasedata(basepath + testcasefilepath);
		//System.out.println(jo);

		// Basic details of test cases from test case json file
		tcid = jo.get("tcId").toString().replaceAll("\"", "");
		Logger.writelog("***********************************Test started for test case id :" , tcid
				, "**************************************");
		desc = jo.get("desc").toString().replaceAll("\"", "");
		Logger.writelog("Test case description: " , desc);
		uri = jo.get("uri").toString().replaceAll("\"", "");
		Logger.writelog("Test URI: " , uri);
		resource = jo.get("resource").toString().replaceAll("\"", "");
		Logger.writelog("Service resource : " , resource);
		parameters = jo.get("parameters").toString().replaceAll("\"", "");
		Logger.writelog("Service parameter: " , parameters);
		httpMethod = jo.get("httpMethod").toString().replaceAll("\"", "");
		Logger.writelog("Service Method: " , httpMethod);
		inputToken = jo.get("inputToken").toString().replaceAll("\"", "");
		Logger.writelog("Service token: " , inputToken);
		inputrequest = jo.get("inputrequest").toString();
		Logger.writelog("Input request for test case: " , inputrequest);

		// Getting all headers in map from test case json file
		JsonElement head = jo.get("headers");
		headers = Jsonparser.getheadermap(head);
		Logger.writelog("Test headers as map: " , headers);

		// Getting all assertion in map from test case json file
		JsonElement asserts = jo.get("assertion");
		assertion = Jsonparser.getassertionmap(asserts);
		Logger.writelog("Assertion applicable for test case as map: " , assertion);

	}

	// This is section where service call is made and response obtained.
	@Test
	@When("I pass all valid inputs to Get service")
	public void service_call() {
		// Write code here that turns the phrase above into concrete actions
		Logger.writelog("Inside service call function - WHEN");

		// run via orignal service
		response = given().filter(logFilter).headers(headers).get(uri + resource);
		// run via mock service
		// response = given().filter(logFilter).headers(headers).get(mockserviceurl);

		res = response.asString();
		CustomLogFilter customLogFilter = (CustomLogFilter) logFilter;
		Logger.writelog("API Request: " , customLogFilter.getRequestBuilder() , "\n" , "API Response:"
				, customLogFilter.getResponseBuilder());
		scenario.write("API Request: " + customLogFilter.getRequestBuilder() + "\n" + "API Response:"
				+ customLogFilter.getResponseBuilder());
	}

	// This is section where all the assertion are performed as per input test case
	// json file.

	@Test
	@Then("I should get valid response from Get service")
	public void validations() {
		Logger.writelog("Inside validation function - THEN");
		// Write code here that turns the phrase above into concrete actions
		for (Entry<String, String[]> entry : assertion.entrySet()) {
			String expectedJpathvalue = null;
			if (entry.getKey().equalsIgnoreCase("jsonPath")) {

				String[] fullassert = entry.getValue();
				String jpath = fullassert[0].trim();
				Logger.writelog("Json path expression is :" , jpath);
				String actualjpathvalue = fullassert[1].trim();
				Logger.writelog("Json path expected value is :" , actualjpathvalue);
				// expectedJpathvalue=JsonPath.read(response.toString(), jpath);
				expectedJpathvalue = Jsonparser.getjsonpathvalue(response, jpath);
				Logger.writelog("Jpath actual value :" , expectedJpathvalue);

				assertEquals(expectedJpathvalue, actualjpathvalue);
			}

			if (entry.getKey().equalsIgnoreCase("httpstatuscd")) {
				String[] expstatuscd = entry.getValue();
				int statuscd = response.getStatusCode();
				String statuscode = Integer.toString(statuscd);
				assertEquals(statuscode, expstatuscd[0]);

			}
			
			if (entry.getKey().equalsIgnoreCase("contains")) {
				String[] expected_exp = entry.getValue();
				String res = response.asString();
				Logger.writelog("Actual expr value :" , expected_exp[0]);
				assertTrue(StringAssertion.assertContains(res, expected_exp[0]));	
				
			}
		}
		System.out.println("***********************************Test ending for test case id :" + tcid
				+ "**************************************");
	}
}
