package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

/*
This is a junit runner class , inside cucumber option we can specify what feature files to run , corresponding step defination to be provided in glue.
*/

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/java/post/post_servicename/features",
		"src/test/java/get/get_servicename/features", "src/test/java/put/put_servicename/features" }, glue = {
				"classpath:post/post_servicename/stepdef/", "classpath:get/get_servicename/stepdef/",
				"classpath:put/put_servicename/stepdef/" }, tags = "@FunctionalTest, @SmokeTest", plugin = {
						"html:target/cucumber-reports", "json:target/cucumber-reports-json/cucumber.json" })
public class RunnerTest {

	@AfterClass
	public static void writeExtentReport() {

		System.out.println("Runner Started");

	}
}
