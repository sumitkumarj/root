package put.put_servicename.stepdef;

import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.CustomLogFilter;
import utils.Jsonparser;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

public class PUT_ServiceName {

	String tcid = null;
	String desc = null;
	String uri = null;
	String resource = null;
	String parameters = null;
	String httpMethod = null;
	String inputToken = null;
	String inputrequest = null;
	HashMap<String, String> headers = null;
	HashMap<String, String> assertion = null;
	HashMap<String, String> database = null;
	Response response = null;
	String res = null;
	Scenario scenario;
	CustomLogFilter logFilter;
	RequestSpecification request;

//Cucumber hook for logging all request response in report.
	@Before
	public void before(Scenario scenario) {
		System.out.println("Scenario name is :" + scenario);
		this.scenario = scenario;
		logFilter = new CustomLogFilter();
		request = RestAssured.with();
	}

	// This is a request builder section - all request parameters are constructed
	// from test case json file.
	@Test
	@Given("^I want to run test case for put service from input data \"([^\"]*)\"$")
	public void request_builder(String testcasefilepath) {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Inside request builder function - GIVEN");
		String basepath = System.getProperty("user.dir");
		JsonObject jo = Jsonparser.gettestcasedata(basepath + testcasefilepath);
		System.out.println(jo);

		// Basic details of test cases from test case json file
		tcid = jo.get("tcId").toString().replaceAll("\"", "");
		System.out.println("***********************************Test started for test case id :" + tcid
				+ "**************************************");
		desc = jo.get("desc").toString().replaceAll("\"", "");
		System.out.println("Test case description: " + desc);
		uri = jo.get("uri").toString().replaceAll("\"", "");
		System.out.println("Test URI: " + uri);
		resource = jo.get("resource").toString().replaceAll("\"", "");
		System.out.println("Service resource : " + resource);
		parameters = jo.get("parameters").toString().replaceAll("\"", "");
		System.out.println("Service parameter: " + parameters);
		httpMethod = jo.get("httpMethod").toString().replaceAll("\"", "");
		System.out.println("Service Method: " + httpMethod);
		inputToken = jo.get("inputToken").toString().replaceAll("\"", "");
		System.out.println("Service token: " + inputToken);
		inputrequest = jo.get("inputrequest").toString();
		System.out.println("Input request for test case: " + inputrequest);

		// Getting all headers in map from test case json file
		JsonElement head = jo.get("headers");
		System.out.println("%%%%%%%% head %%%%%%%%%p: " + head);
		headers = Jsonparser.getheadermap(head);
		System.out.println("Test headers as map: " + headers);

		// Getting all assertion in map from test case json file
		JsonElement asserts = jo.get("assertion");
		assertion = Jsonparser.getheadermap(asserts);
		System.out.println("Assertion applicable for test case as map: " + assertion);

	}

	// This is section where service call is made and response obtained.
	@Test
	@When("I pass all valid inputs to put service")
	public void service_call() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Inside service call function - WHEN");
		response = given().filter(logFilter).body(inputrequest).baseUri(uri).basePath(resource).headers(headers)
				.put();
		res = response.asString();
		CustomLogFilter customLogFilter = (CustomLogFilter) logFilter;
		System.out.println("API Request: " + customLogFilter.getRequestBuilder() + "\n" + "API Response:"
				+ customLogFilter.getResponseBuilder());
		scenario.write("API Request: " + customLogFilter.getRequestBuilder() + "\n" + "API Response:"
				+ customLogFilter.getResponseBuilder());
		// System.out.println("Service response is " + response.asString());
	}

	// This is section where all the assertion are performed as per input test case
	// json file.
	@Test
	@Then("I should get valid response from put service")
	public void validations() {
		System.out.println("Inside validation function - THEN");
		// Write code here that turns the phrase above into concrete actions
		for (Map.Entry<String, String> entry : assertion.entrySet()) {
			String expectedJpathvalue = null;
			//Checking type of assertion and then deciding what to validate.
			if (entry.getKey().equalsIgnoreCase("jsonPath")) {
				String[] fullassert = entry.getValue().split("::");
				String jpath = fullassert[0];
				System.out.println("Json path expression is :" + jpath);
				String actualjpathvalue = fullassert[1];
				System.out.println("Json path expected value is :" + actualjpathvalue);
				// call json path extractor to get value based on jpath provided
				expectedJpathvalue = Jsonparser.getjsonpathvalue(response, jpath);
				System.out.println("Jpath actual value :" + expectedJpathvalue);

				assertEquals(expectedJpathvalue, actualjpathvalue);

			}

			if (entry.getKey().equalsIgnoreCase("httpstatuscd")) {
				String expstatuscd = entry.getValue();
				int statuscd = response.getStatusCode();
				String statuscode = Integer.toString(statuscd);
				assertEquals(statuscode, expstatuscd);

			}

		}
		System.out.println("***********************************Test ending for test case id :" + tcid
				+ "**************************************");
	}

}
